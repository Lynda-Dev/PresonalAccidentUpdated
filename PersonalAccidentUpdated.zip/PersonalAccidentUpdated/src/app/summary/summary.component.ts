import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as pdfMake from "pdfmake/build/pdfmake";
import * as pdfFonts from "pdfmake/build/vfs_fonts";
import { DateService } from '../services/Date.services';
import { FormService } from '../services/form.services';



declare var require: any;
const htmlToPdfmake = require("html-to-pdfmake");
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})




export class SummaryComponent implements OnInit {

  @ViewChild('pdfTable')
  pdfTable!: ElementRef;

  public policyNo = '';
  public message = '';
  public name = '';
  public productType = '';
  public address = '';
  public amount = '';
  public sdate = '';
  public edate = '';

  public db = '';
  public pd = '';
  public me = '';
  public pm = 0;


  constructor(
    private formService: FormService,

    private route: ActivatedRoute, private dateserv: DateService) {
    this.policyNo = this.route.snapshot.params.policyNo;
    this.message = this.route.snapshot.params.message;
    this.name = this.route.snapshot.params.name;
    this.productType = this.route.snapshot.params.type;
    this.amount = this.route.snapshot.params.amount;
    this.address = this.route.snapshot.params.address;
    // this.date = this.route.snapshot.params.date;
    console.log( 'this.productType');
    console.log( this.productType);
    this.getBenefits()
    this._getDate();

  }

  ngOnInit(): void {
  }


  _getDate() {
    this.dateserv.getdate(this.policyNo).subscribe(res => {
      console.log('date response is ');

      var ResponseData: any = res;
      console.log(res);
      this.sdate = ResponseData['startDate']
      this.edate = ResponseData['endDate']
    })
  }
  getBenefits() {
    var protype = this.productType.toLowerCase();

    if (protype == 'bronze') {
      var resp: any = this.formService.getbenefits(1)
      this.db = resp['db'];
      this.pd = resp['PermanentDisability'];
      this.me = resp['MedicalExpenses'];
      this.pm = parseInt(resp['Premium']);

    } else if (protype == 'gold') {
      var resp: any = this.formService.getbenefits(3)
      this.db = resp['db'];
      this.pd = resp['PermanentDisability'];
      this.me = resp['MedicalExpenses'];
      this.pm = parseInt(resp['Premium']);

    }
    else if (protype == 'silver') {
      var resp: any = this.formService.getbenefits(2)
      this.db = resp['db'];
      this.pd = resp['PermanentDisability'];
      this.me = resp['MedicalExpenses'];
      this.pm = parseInt(resp['Premium']);

    }
    else if (protype == 'platinum') {
      var resp: any = this.formService.getbenefits(4)
      this.db = resp['db'];
      this.pd = resp['PermanentDisability'];
      this.me = resp['MedicalExpenses'];
      this.pm = parseInt(resp['Premium']);
    }
    console.log('pm');
    console.log(protype);
    console.log(this.pm);
    console.log(resp['name']);
  }

  // public downloadAsPDF() {
  //   // const pdfTable = this.pdfTable.nativeElement;
  //   var html = htmlToPdfmake(innerHTML);
  //   const documentDefinition = { content: html };
  //   pdfMake.createPdf(documentDefinition).download();

  // }

}
function innerHTML(innerHTML: any) {
  throw new Error('Function not implemented.');
}

