import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-care',
  templateUrl: './customer-care.component.html',
  styleUrls: ['./customer-care.component.css']
})
export class CustomerCareComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
