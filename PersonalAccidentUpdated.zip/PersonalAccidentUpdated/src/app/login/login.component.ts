import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.services';
import { FormControl, FormGroupDirective, NgForm, Validators, FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthResponse, Login } from '../services/login.Interface';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit { 
  public loginErr = false;
  public loginIn = false;

  loginFormGroup!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private loginService: LoginService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.loginFormGroup = this.fb.group(
      {
        email: ['', Validators.required],
        kokoro: ['', Validators.required]
      }
    )
  }

  loginUSer() {
    this.loginErr = false;

    const payload: Login = {
      email: this.loginFormGroup.get('email')?.value, 
      kokoro: this.loginFormGroup.get('kokoro')?.value
    }

    this.loginService.login(payload)
      .subscribe(
        res => {
          console.log('response: ', res);

          let response: any; 
          
          response = res;

          localStorage.setItem('email', response['data']['email']);
          localStorage.setItem('name', response['data']['name']);
          localStorage.setItem('token', response['data']['bearerToken']);

          this.router.navigate(['/profile'], { relativeTo: this.route });
        },
        () => {
          this.loginErr = true;
        }
      )
    
  }
}
