import { Component, ElementRef, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormService } from '../services/form.services';
import { PolicyVerificationService } from '../services/policy-verification.service';
import {
  FormControl,
  FormGroupDirective,
  NgForm,
  Validators,
  FormArray,
  FormBuilder,
  FormGroup,
  Form,
  MaxLengthValidator,
} from '@angular/forms';

import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker'
import { Formkyc, Policy } from '../services/form.interface';
import { baseUrl } from '../baseurl';
import * as moment from 'moment';


@Component({
  selector: 'app-kyc',
  templateUrl: './kyc.component.html',
  styleUrls: ['./kyc.component.css'],
})
export class KYCComponent implements OnInit {
  active = 1;
  MatMomentDateModule: any
  public kycResult: any;

  get machineryUserResponseyes() {
    if (this.kycFormGroup.get('machineryUserResponse')?.value === 'yes') {
      return true
    } else {
      return false
    }
  }

  get accidentYes() {
    if (this.kycFormGroup.get('accidentHistory')?.value === 'true') {
      return true
    } else {
      return false
    }
  }

  get heldPolicyYes() {
    if (this.kycFormGroup.get('activePAPolicyResponse')?.value === 'yes') {
      return true
    } else {
      return false
    }
  }

  get previousaccidentYes() {
    if (this.kycFormGroup.get('previousAccidentResponse')?.value === 'yes') {
      return true
    } else {
      return false
    }
  }

  get consultationYes() {
    if (this.kycFormGroup.get('consultatationResponse')?.value === 'yes') {
      return true
    } else {
      return false
    }
  }

  get hospitalVisitYes() {
    if (this.kycFormGroup.get('hospitalVisitResponse')?.value === 'yes') {
      return true
    } else {
      return false
    }
  }

  get medicationYes() {
    if (this.kycFormGroup.get('medicationResponse')?.value === 'yes') {
      return true
    } else {
      return false
    }
  }


  get xraysYes() {
    if (this.kycFormGroup.get('medicalTestResponse')?.value === 'yes') {
      return true
    } else {
      return false
    }
  }

  get nightUrinateYes() {
    if (this.kycFormGroup.get('nightUrinate')?.value === 'yes') {
      return true
    } else {
      return false
    }
  }


  get nationalityYes() {
    console.log(this.kycFormGroup.get('nationality')?.value)
    if (this.kycFormGroup.get('nationality')?.value === '2') {
      return true
    } else {
      return false
    }
  }


  get notnationalityYes() {
    console.log(this.kycFormGroup.get('nationality')?.value)
    if (this.kycFormGroup.get('nationality')?.value === '1') {
      return true
    } else {
      return false
    }
  }






  public allState = [];
  public product: any;

  // get all LGAs
  public allLGA = [];
  public lgaById = [];
  public lgaById2 = [];


  public loadingSubmit: boolean = false;

  // form submission response control
  public submitErr = false;
  public submitSucc = false;

  public submit1In = false;

  // image upload
  public hasImageUrl = false;
  public imageUrl = '';

  // upload endpoint control
  public uploadingImage = false;
  public uploadSuccess = false;
  public uploadError = false;

  // show activeThirdParty if customer has third-party policy
  public hasActiveThirdParty = false;

  // Show if ID type other is selected
  public idTypeOther = false;

  // medical fitness
  public isFit = false;

  // product type gotten from URL
  public productType = 1;

  // verifying indicators
  public verifyingPolicy = false;
  public policyIsValid = false;
  public policyChecked = false;

  // medical form responses
  public show = {
    previousAccidentResponse: false,
  };

  // agree checker
  public agreed = false;

  public submitload = false;
  public click = false;

  // all required field checker
  public hasFristName = false;
  public hasLastName = false;
  public hasPhone = false;
  public hasEmail = false;
  public hasDob = false;
  public hasGender = false;
  public hasAddress = false;
  public hasMarital = false;
  public homeTown = false;


  kycFormGroup!: FormGroup;
  public cName: any;


  private formData: FormData = new FormData();
  public fileLength = 0;
  today = moment().toISOString();
  minus18 = moment().subtract(18, 'years').toISOString();

  maxDate = moment();

  maxDater = moment("12-25-2021", "MM-DD-YYYY");
  dayee = new Date(2021, 9, 16);
  dadyee = moment().format("MM-DD-YYYY");
  daawdyee = Date.now()
  efae = moment(Date.now(), "MM-DD-YYYY");


  constructor(
    private fb: FormBuilder,
    private formService: FormService,
    private router: Router,
    private route: ActivatedRoute,
    private policyService: PolicyVerificationService,
    private elementRef: ElementRef,

  ) {
    // this.maxDate = new Date();
  }

  ngOnInit(): void {

    // {
    //   const isRequired = this.kycFormGroup.controls[this.cName]?.errors?.required;
    //   if (isRequired) {
    //     this.elementRef.nativeElement.innerHTML = '*';
    //   }else{
    //     this.elementRef.nativeElement.innerHTML = '';
    //   }
    // }
    const product: any = this.route.snapshot.queryParamMap.get('product');

    this.getAllStates();
    this.getAllLGAs();
    if (product) {
      this.productType = parseInt(product);
    }
    this.getBenefits();

    this.kycFormGroup = this.fb.group({
      height: [''],
      weight: [''],
      presentHealthState: [''],
      generalHealthState: [''],
      varyHealth: [''],
      previousAccident: [''],
      consultatation: [''],
      healthComplaint: ['N/A'],
      hospitalVisit: [''],
      medication: [''],
      prescription: [''],
      exceededPrescription: [''],
      medicalTest: [''],
      nightUrinate: [''],
      urineFrequency: [''],
      urineDuration: [''],
      breakdown: [''],
      entDisease: [''],
      cardio: [''],
      highBP: [''],
      previousAccidentResponse: [''],
      consultatationResponse: [''],
      hospitalVisitResponse: [''],
      medicationResponse: [''],
      prescriptionResponse: [''],
      medicalTestResponse: [''],

      firstName: [''],
      lastName: [''],
      email: [''],
      mobilePhone: ['', [Validators.maxLength(11), Validators.pattern(/[0-9]*/)]],
      homePhone: ['N/A', [Validators.maxLength(11), Validators.pattern(/[0-9]*/)]],
      address: [''],
      stateOfOriginId: [''],
      lgaId: [''],
      homeTown: [''],
      nationality: [''],
      idType: [''],
      idNumber: [''],
      idIssueLocation: ['N/A'],
      idIssueDate: [''],
      idURL: [''],
      dob: [''],
      gender: [''],
      maritalStatus: [''],
      mothersMaidenName: ['N/A'],
      occupation: [''],
      employer: [''],
      employmentType: ['N/A'],
      employerAddress: [''],
      employerPhone: ['N/A', [Validators.maxLength(11), Validators.pattern(/[0-9]*/)]],
      addressState: [''],
      addressLGA: [''],

      fit: [''],
      frequentTraveller: ['N/A'],
      machineryUser: [''],
      accidentHistory: [''],
      activePAPolicy: [''],
      activeThirdParty: [''],
      thirdPartyPolicyNo: [''],
      activePAPolicyResponse: [''],
      machineryUserResponse: [''],

      agree: ['', Validators.required],
    });
  }

  validateEmail(email: string) {
    const re =
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }



  getBenefits() {
    this.product = this.formService.getbenefits(this.productType)
  }
  requiredFieldChangeHandler(event: any) {
    const formControlName = event.target.id;
    const fieldValue = this.kycFormGroup.get(formControlName)?.value;

    switch (formControlName) {
      case 'firstName':
        if (fieldValue.length > 1) {
          this.hasFristName = true;
        } else {
          this.hasFristName = false;
        }

        break;
      case 'lastName':
        if (fieldValue.length > 1) {
          this.hasLastName = true;
        } else {
          this.hasLastName = false;
        }

        break;
      case 'email':
        if (this.validateEmail(fieldValue)) {
          this.hasEmail = true;
        } else {
          this.hasEmail = false;
        }

        break;

      case 'mobilePhone':
        if (fieldValue.length > 10) {
          this.hasPhone = true;
        } else {
          this.hasPhone = false;
        }

        break;

      case 'gender':
        if (fieldValue.length > 1) {
          this.hasGender = true;
        } else {
          this.hasGender = false;
        }

        break;

      case 'address':
        if (fieldValue.length > 1) {
          this.hasAddress = true;
        } else {
          this.hasAddress = false;
        }

        break;

      case 'maritalStatus':
        if (fieldValue.length > 1) {
          this.hasMarital = true;
        } else {
          this.hasMarital = false;
        }

        break;


      case 'homeTown':
        if (fieldValue.length > 1) {
          this.hasFristName = true;
        } else {
          this.hasFristName = false;
        }

        break;
      default:
        break;
    }

    console.log('value: ', this.kycFormGroup.get(formControlName)?.value);
  }

  phoneChangeHandler(formControlName: string) {
    const inputValue = this.kycFormGroup.get(formControlName)?.value;

    this.kycFormGroup.patchValue(
      {
        [formControlName]: inputValue.match(/[0-9]*/)[0]
      }
    )

    console.log('value1: ', inputValue.match(/[0-9]*/))
  }

  submitloadcheck() {
    if (this.click == true) {
      this.submitload = true;
    } else {

    }
  }

  getAllStates() {
    this.formService.getState().subscribe((res) => {
      const response: any = res;

      this.allState = response['data'];
    });
  }

  getAllLGAs() {
    this.formService.getLga().subscribe((res) => {
      const response: any = res;

      this.allLGA = response['data'];
    });
  }

  stateChangeHandler1(event: Event) {
    // reset list to empty on state change
    this.lgaById = [];

    const selected: any = event;

    for (let i = 0; i < this.allLGA.length; i++) {
      const element = this.allLGA[i]['stateId'];

      if (element === selected) {
        this.lgaById.push(this.allLGA[i]);
      }
    }
  }

  stateChangeHandler2(event: Event) {
    // reset list to empty on state change
    this.lgaById2 = [];

    const selected: any = event;

    for (let i = 0; i < this.allLGA.length; i++) {
      const element = this.allLGA[i]['stateId'];

      if (element === selected) {
        this.lgaById2.push(this.allLGA[i]);
      }
    }
  }

  agreeChangeHandler() {
    this.agreed = !this.agreed;

    console.log('agree: ', this.agreed);
  }

  radioChangeHandler(event: any, inputName: string) {
    console.log('radio: ', event['source']['name']);
    console.log('value: ', event['value']);

    const formCtrlName: string = event['source']['name'];
    const elementValue = event['value'];

    if (elementValue === 'yes') {
      switch (formCtrlName) {
        case 'previousAccidentResponse':
          this.show.previousAccidentResponse = true;
          break;

        default:
          break;
      }
    }
  }

  thirdPartyPolicyClick(event: any) {
    event.preventDefault();

    this.verifyingPolicy = true;
    this.policyChecked = true;

    const policyNo: Policy = {
      policyNo: this.kycFormGroup.get('thirdPartyPolicyNo')?.value,
    };

    this.policyService.checkPolicy(policyNo).subscribe(
      (res) => {
        const response: any = res;

        if (response['code'] === '00') {
          this.policyIsValid = true;
        } else {
          this.policyIsValid = false;
        }

        this.verifyingPolicy = false;
      },
      (err) => {
        this.policyIsValid = false;
        this.verifyingPolicy = false;
      }
    );

    console.log(
      'thirdPartyPolicyNo: ',
      this.kycFormGroup.get('thirdPartyPolicyNo')?.value
    );
  }



  fitnessOnChange() {
    const status = this.kycFormGroup.get('fit')?.value;

    this.isFit = status === '1' ? false : true;

    console.log('fit: ', this.isFit);
  }

  setFileOnChange(event: any) {
    event.preventDefault();

    const [file] = event.target.files;
    this.fileLength = event.target.files.length;

    console.log('file: ', file);

    this.formData.append('file', file);
  }



  upload(event: any) {
    this.uploadingImage = true;

    this.uploadSuccess = false;
    this.uploadError = false;

    event.preventDefault();

    if (this.fileLength > 0) {
      this.formService.fileUpload(this.formData).subscribe(
        (res) => {
          const response: any = res;
          this.imageUrl = baseUrl + '/' + response.filePath;
          this.hasImageUrl = true;

          this.uploadSuccess = true;
          this.uploadingImage = false;
        },
        () => {
          this.uploadError = true;
        }
      );
    }
  }

  getStateById(stateId: any) {
    for (let i = 0; i < this.allState.length; i++) {
      const element = this.allState[i]['id'];

      if (element === stateId) {
        return this.allState[i]['name'];
      }
    }

    return 0;
  }

  activePolicyOnChange(event: any) {
    const status = this.kycFormGroup.get('activeThirdParty')?.value;
    this.hasActiveThirdParty = status === '1' ? true : false;
    console.log();
  }

  idTypeChange() {
    const status = this.kycFormGroup.get('idType')?.value;

    this.idTypeOther = status === 'Others' ? true : false;
  }

  private clickUpload() {

    document.getElementById('btnuploadfile')?.click();

    setTimeout(() => {
      return true
    }, 1000);

  }


  onSubmit() {

    this.clickUpload();

    this.submitErr = false;
    this.submitSucc = false;




    let lgaName: string;

    try {
      lgaName =
        this.lgaById[this.kycFormGroup.get('addressLGA')?.value]['name'];
    } catch (error) {
      lgaName = '';
    }

    const fullAddress =
      this.kycFormGroup.get('address')?.value +
      ', ' +
      lgaName +
      ', ' +
      this.getStateById(this.kycFormGroup.get('addressState')?.value);

    const payload: Formkyc = {
      medicalRequest: {
        height: this.isFit ? this.kycFormGroup.get('height')?.value : 'N/A',
        weight: this.isFit ? this.kycFormGroup.get('weight')?.value : 'N/A',
        presentHealthState: this.isFit
          ? this.kycFormGroup.get('presentHealthState')?.value
          : 'N/A',
        generalHealthState: this.isFit
          ? this.kycFormGroup.get('generalHealthState')?.value
          : 'N/A',
        varyHealth: this.isFit
          ? this.kycFormGroup.get('varyHealth')?.value
          : 'N/A',
        previousAccident:
          this.kycFormGroup.get('previousAccidentResponse')?.value === 'yes'
            ? this.kycFormGroup.get('previousAccident')?.value
            : 'N/A',
        consultatation:
          this.kycFormGroup.get('consultatationResponse')?.value === 'yes'
            ? this.kycFormGroup.get('consultatation')?.value
            : 'N/A',
        healthComplaint: this.kycFormGroup.get('healthComplaint')?.value,
        hospitalVisit:
          this.kycFormGroup.get('hospitalVisitResponse')?.value === 'yes'
            ? this.kycFormGroup.get('hospitalVisit')?.value
            : 'N/A',
        medication:
          this.kycFormGroup.get('medicationResponse')?.value === 'yes'
            ? this.kycFormGroup.get('medication')?.value
            : 'N/A',
        prescription: 'N/A',
        exceededPrescription: this.isFit
          ? this.kycFormGroup.get('exceededPrescription')?.value
          : 'N/A',
        medicalTest:
          this.kycFormGroup.get('medicalTestResponse')?.value === 'yes'
            ? this.kycFormGroup.get('medicalTest')?.value
            : 'N/A',
        nightUrinate: this.isFit
          ? this.kycFormGroup.get('nightUrinate')?.value
          : 'N/A',
        urineFrequency:
          this.kycFormGroup.get('nightUrinate')?.value === 'yes'
            ? this.kycFormGroup.get('urineFrequency')?.value
            : 'N/A',
        urineDuration:
          this.kycFormGroup.get('nightUrinate')?.value === 'yes'
            ? this.kycFormGroup.get('urineDuration')?.value
            : 'N/A',
        breakdown:
          this.kycFormGroup.get('breakdown')?.value === ''
            ? 'false'
            : 'true',
        entDisease:
          this.kycFormGroup.get('entDisease')?.value === ''
            ? 'false'
            : 'true',
        cardio:
          this.kycFormGroup.get('cardio')?.value === ''
            ? 'false'
            : 'true',
        highBP:
          this.kycFormGroup.get('highBP')?.value === ''
            ? 'false'
            : 'true',
      },
      kycRequest: {
        firstName: this.kycFormGroup.get('firstName')?.value,
        lastName: this.kycFormGroup.get('lastName')?.value,
        email: this.kycFormGroup.get('email')?.value,
        mobilePhone: this.kycFormGroup.get('mobilePhone')?.value,
        homePhone: this.kycFormGroup.get('homePhone')?.value,
        address: this.kycFormGroup.get('address')?.value,
        stateOfOriginId: this.kycFormGroup.get('stateOfOriginId')?.value,
        lgaId: this.kycFormGroup.get('lgaId')?.value,
        homeTown: this.kycFormGroup.get('homeTown')?.value,
        nationality: this.kycFormGroup.get('nationality')?.value,
        idType: this.kycFormGroup.get('idType')?.value,
        idURL: this.imageUrl,
        idIssueLocation: this.kycFormGroup.get('idIssueLocation')?.value,
        idNumber: this.kycFormGroup.get('idNumber')?.value,
        idIssueDate: this.kycFormGroup.get('idIssueDate')?.value,
        dob: this.kycFormGroup.get('dob')?.value,
        gender: this.kycFormGroup.get('gender')?.value,
        maritalStatus: this.kycFormGroup.get('maritalStatus')?.value,
        mothersMaidenName: this.kycFormGroup.get('mothersMaidenName')?.value,
        occupation: this.kycFormGroup.get('occupation')?.value,
        employmentType: this.kycFormGroup.get('employmentType')?.value,
        employer: this.kycFormGroup.get('employer')?.value,
        employerAddress: this.kycFormGroup.get('employerAddress')?.value,
        employerPhone: this.kycFormGroup.get('employerPhone')?.value,
      },
      paRequest: {
        fit: this.kycFormGroup.get('fit')?.value === '1' ? true : false,
        productId: this.productType,
        discount: this.policyIsValid,
        frequentTraveller: this.kycFormGroup.get('employerPhone')?.value,
        machineryUser:
          this.kycFormGroup.get('machineryUserResponse')?.value === 'yes'
            ? this.kycFormGroup.get('machineryUser')?.value
            : 'N/A',
        accidentHistory: this.kycFormGroup.get('accidentHistory')?.value == 'yes'
          ? this.kycFormGroup.get('accident')?.value
          : 'N/A',
        activePAPolicy:
          this.kycFormGroup.get('activePAPolicyResponse')?.value === 'yes'
            ? this.kycFormGroup.get('activePAPolicy')?.value
            : 'N/A',
      },
    };



    // var formDob = this.kycFormGroup.get('dob')?.value



    console.log('Payload: ', payload);

    this.formService.SaveData(payload)
      .subscribe(
        res => {
          console.log(res);
          console.log()
          this.kycResult = res;


          this.kycFormGroup.reset();

          this.policyChecked = false;
          this.policyIsValid = false

          this.submitSucc = true;

          if (this.kycResult['status'] == true) {
            console.log('This is true');
            console.log(this.kycResult['status']);
            console.log('premium');
            console.log(this.kycResult['data']['premium'])

            var dob = payload.kycRequest.dob
            var lgaId = payload.kycRequest.lgaId
            var employerAddress = payload.kycRequest.employerAddress
            var address = payload.kycRequest.address

            var stateOfOriginId = payload.kycRequest.stateOfOriginId
            var email = payload.kycRequest.email
            var maritalStatus = payload.kycRequest.maritalStatus
            var gender = payload.kycRequest.gender
            var stateOfOriginId = payload.kycRequest.stateOfOriginId

            var mobilePhone = payload.kycRequest.mobilePhone

            var name = payload.kycRequest.firstName + ' ' + payload.kycRequest.lastName
            var amount = this.kycResult['data']['premium']
            var productType = '';
            var tranId = this.kycResult['data']['transactionId']

            if (this.productType == 1) {
              productType = 'Bronze';
            } else if (this.productType == 2) {
              productType = 'Silver';
            } else if (this.productType == 3) {
              productType = 'Gold';
            } else if (this.productType == 4) {
              productType = 'Platinum';
            }

            setTimeout(() => {
              this.router.navigate(['/payment', {
                email: email, name: name, amount: amount,
                productType: productType, tranId: tranId, dob: dob, lgaId: lgaId, employerAddress: employerAddress,
                address: address, stateOfOriginId: stateOfOriginId, maritalStatus: maritalStatus, gender: gender,
                mobilePhone: mobilePhone
              }]);

            }, 1000);


          } else {
            console.log('This is not true');
          }




        },
        () => {
          this.submitErr = true;
        })
  }
}
