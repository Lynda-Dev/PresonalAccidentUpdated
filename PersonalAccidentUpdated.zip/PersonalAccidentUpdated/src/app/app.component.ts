import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'MPA';

  // images = ['Art1', 'Art2', 'Art3'].map((n) => `../assets/img/${n}.png`);

  ngOnInit() {
  }  // oninit
}
