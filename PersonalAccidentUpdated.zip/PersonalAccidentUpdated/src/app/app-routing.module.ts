import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { KYCComponent } from '../app/kyc/kyc.component';
import { HomeComponent } from '../app/home/home.component'
import { LoginComponent } from './login/login.component';
import { LandingComponent } from './landing/landing.component';
import { ProfileLoginComponent } from './profile-login/profile-login.component';
import { RegisterComponent } from './register/register.component';
import { LoginAdminComponent } from './login-admin/login-admin.component';
import { ResetPassComponent } from './reset-pass/reset-pass.component';
import { PaymentFormComponent } from './payment-form/payment-form.component';
import { SummaryComponent } from './summary/summary.component';


const routes: Routes = [
  {
    path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    component: HomeComponent,
  },
  {
    path: 'kyc',
    component: KYCComponent
  },
  {
    path: 'login',
    component: LandingComponent
  },

  {
    path: 'profile',
    component: ProfileLoginComponent
  },

  {
    path: 'register',
    component: RegisterComponent
  },

  {
    path: 'admin',
    component: LoginAdminComponent
  },

  {
    path: 'reset',
    component: ResetPassComponent
  },

  {
    path: 'payment',
    component: PaymentFormComponent
  },

  {
    path: 'payment',
    component: PaymentFormComponent
  },

  {
    path: 'summary',
    component: SummaryComponent
  }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
