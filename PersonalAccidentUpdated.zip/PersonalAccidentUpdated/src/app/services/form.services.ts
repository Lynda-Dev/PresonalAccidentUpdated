import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { baseUrl } from '../baseurl';
import { Formkyc } from './form.interface';


@Injectable({
  providedIn: 'root'
})
export class FormService {
  private formUrl = baseUrl + '/api/Initiate';
  constructor(
    private http: HttpClient
  ) { }


  public kyc(kycFormUser: Formkyc) {
    const httpOptions = this.httpClientHeaders();

    return this.http.post(this.formUrl, kycFormUser, httpOptions);
  }

  fileUpload(uploadedFile: any) {
    console.log('uploadedFile: ', uploadedFile);

    const url = baseUrl + '/api/Initiate/upload';

    return this.http.post(url, uploadedFile)
  }

  getState() {
    const httpOptions = this.httpClientHeaders();
    const stateUrl = baseUrl + '/api/locale';

    return this.http.get(stateUrl, httpOptions);
  }

  getLga() {
    const httpOptions = this.httpClientHeaders();
    const stateUrl = baseUrl + '/api/locale/lga';

    return this.http.get(stateUrl, httpOptions);
  }

  getbenefits(index: number) {
    var benefits = [

      {
        "name": "Bronze",
        "Premium": "1000",
        "db": "200000",
        "PermanentDisability": "200000",
        "MedicalExpenses": "10000"
      },

      {
        "name": "Silver",
        "Premium": "1500",
        "db": "300000",
        "PermanentDisability": "300000",
        "MedicalExpenses": "15000"
      },

        {
          "name": "Gold",
          "Premium": "2000",
          "db": "400000",
          "PermanentDisability": "400000",
          "MedicalExpenses": "20000"
        },

      {
        "name": "Platinum",
        "Premium": "2500",
        "db": "500000",
        "PermanentDisability": "500000",
        "MedicalExpenses": "25000"
      },


    ]


    if (index == 5) {
      return benefits;
    } else {
      return benefits[index - 1];
    }

  }

  setkycFormUser(
    value: boolean,
    role: string,
  ) {
    console.log(' this is SUBMIT ');

  }

  SaveData(payload: Formkyc) {
    const httpOptions = this.httpClientHeaders();

    return this.http.post(this.formUrl, payload, httpOptions)

  }

  ////////////////////////////////
  // headers for HTTPCLIENT calls
  private httpClientHeaders() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
  }


}

function form(kycFormUser: any, Formkyc: any) {
  throw new Error('Function not implemented.');
}
