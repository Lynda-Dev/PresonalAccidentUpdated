import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { baseUrl } from '../baseurl';
import { Policy } from './form.interface';

@Injectable({
  providedIn: 'root'
})
export class PolicyVerificationService {
  private verificationUrl = baseUrl + '/api/PolicyChecker';

  constructor(
    private http: HttpClient
  ) { }

  public checkPolicy(payload: Policy) {
    const httpOptions = this.httpClientHeaders();

    return this.http.post(this.verificationUrl, payload, httpOptions);
  }

  // headers for HTTPCLIENT calls
  private httpClientHeaders() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
  }
}
