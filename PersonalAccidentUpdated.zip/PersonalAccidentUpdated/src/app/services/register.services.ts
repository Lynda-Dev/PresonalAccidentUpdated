import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { baseUrl } from '../baseurl';
import { Register } from './register.interface';
import { Summary } from '@angular/compiler';
import { Email } from './summary.interface';


@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  private formUrl = baseUrl + '/api/CustomerAuth/register';
  private createploicyUrl = baseUrl + '/api/Initiate/payment';
  private sendemailUrl = baseUrl + '/api/Initiate/email';

  constructor(
    private http: HttpClient,
    private router: Router,
  ) { }
 
  public register(regFormUser: Register) {
    const httpOptions = this.httpClientHeaders(); 
    return this.http.post(this.formUrl, regFormUser, httpOptions);
  }

  
  public createpolicy(payload: any) {
    const httpOptions = this.httpClientHeaders();

    return this.http.post(this.createploicyUrl, payload);
  }

  public sendEmail(payload: Email) {
    const httpOptions = this.httpClientHeaders(); 
    return this.http.post(this.sendemailUrl, payload, httpOptions);
  }


  setregFormUser(
    value: boolean,
    role: string,
  ) {
    console.log(' this is SUBMIT ');

  }

  //Save Register
SaveData(payload : Register)
{
  const httpOptions = this.httpClientHeaders();

  return this.http.post(this.formUrl, payload, httpOptions)
    
  }

  ////////////////////////////////
  // headers for HTTPCLIENT calls
  private httpClientHeaders() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
  }
}

function form(regFormUser: any, Register: any) {
  throw new Error('Function not implemented.');
}
