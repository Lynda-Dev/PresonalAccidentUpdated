import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { baseUrl } from '../baseurl';
import { Login } from './login.Interface';
import { Reset } from './reset.interface';


@Injectable({
  providedIn: 'root'
})
export class ResetService {
  private resetUrl = baseUrl + '/api/CustomerAuth/reset-password';
  constructor(
    private http: HttpClient,
    private router: Router,
  ) { }


  public reset(resetUser: Reset) {
    const httpOptions = this.httpClientHeaders();

    return this.http.post(this.resetUrl, resetUser, httpOptions);
  }


  setResetUser(
    value: boolean,
    role: string,
  ) {
    console.log(' this is reset ');

  }

  ////////////////////////////////
  // headers for HTTPCLIENT calls
  private httpClientHeaders() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
  }
}