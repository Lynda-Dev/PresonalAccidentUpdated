import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { baseUrl } from '../baseurl';
import { Login } from './login.Interface';
import { Admin } from './login-admin.interface';


@Injectable({
  providedIn: 'root'
})
export class AdminService {
  
  private adminUrl = baseUrl + '/api/Auth';
  constructor(
    private http: HttpClient,
    private router: Router,
  ) { }


  public admin(adminUSer: Admin) {
    const httpOptions = this.httpClientHeaders();

    return this.http.post(this.adminUrl, adminUSer, httpOptions);
  }


  setAdminUser(
    value: boolean,
    role: string,
  ) {
    console.log(' this is login-admin ');

  }

  ////////////////////////////////
  // headers for HTTPCLIENT calls
  private httpClientHeaders() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
  }
}