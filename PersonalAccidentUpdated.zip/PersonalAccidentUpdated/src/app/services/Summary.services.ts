import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { baseUrl } from '../baseurl';
import { Pay } from './summary.interface';


@Injectable({
  providedIn: 'root'
})
export class SummaryService {
  private summaryUrl = baseUrl + '/api/Initiate/payment';
  constructor(
    private http: HttpClient,
    private router: Router,
  ) { }


  public register(regFormUser: Pay) {
    const httpOptions = this.httpClientHeaders();

    return this.http.post(this.summaryUrl, regFormUser, httpOptions);
  }


  setregFormUser(
    value: boolean,
    role: string,
  ) {
    console.log(' this is SUBMIT ');

  }

  //Save Register
SaveData(payload : Pay)
{
  const httpOptions = this.httpClientHeaders();

  return this.http.post(this.summaryUrl, payload, httpOptions)
    
  }

  ////////////////////////////////
  // headers for HTTPCLIENT calls
  private httpClientHeaders() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
  }
}

function form(regFormUser: any, Register: any) {
  throw new Error('Function not implemented.');
}
