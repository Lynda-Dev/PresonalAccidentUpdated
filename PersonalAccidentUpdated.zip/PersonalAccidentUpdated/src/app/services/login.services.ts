import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { baseUrl } from '../baseurl';
import { Login } from './login.Interface';


@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private loginUrl = baseUrl + '/api/CustomerAuth';
  constructor(
    private http: HttpClient,
    private router: Router,
  ) { }


  public login(loginUser: Login) {
    const httpOptions = this.httpClientHeaders();

    return this.http.post(this.loginUrl, loginUser, httpOptions);
  }


  setLoginUser(
    value: boolean,
    role: string,
  ) {
    console.log(' this is login ');

  }

  ////////////////////////////////
  // headers for HTTPCLIENT calls
  private httpClientHeaders() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
  }
}