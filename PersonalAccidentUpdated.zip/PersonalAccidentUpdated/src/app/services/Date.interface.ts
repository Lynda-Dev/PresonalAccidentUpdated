export interface Date

    {
        startDate: string;
        endDate: string;
      }
         
     
    