export interface Login {
    email: string;
    kokoro: string;
  }

export interface AuthResponse {
  status: string,
  code: string,
  data: {
    bearerToken: string,
    name: string,
    email: string
  }
}