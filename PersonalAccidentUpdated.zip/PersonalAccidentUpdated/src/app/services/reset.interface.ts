export interface Reset {
    confirmkokoro: string;
    kokoro: string;
    email: string;
   
}
