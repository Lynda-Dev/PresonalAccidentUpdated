export interface Register {

    firstName: string;
    lastName: string;
    email: string;
    mobilePhone: string;
    kokoro: string;

}



