import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { baseUrl } from '../baseurl';
import { Login } from './login.Interface';


@Injectable({
  providedIn: 'root'
})
export class DateService {
  private DateUrl =  'http://172.31.60.146/PrintCertificate/api/PrintCert';
  constructor(
    private http: HttpClient,
    private router: Router,
  ) { }


  public getdate(policyNumber: String) {

    var poldata =  

        {
            "policyNo": policyNumber
          }

    
    const httpOptions = this.httpClientHeaders();

    return this.http.post(this.DateUrl, poldata, httpOptions);
  }


  setLoginUser(
    value: boolean,
    role: string,
  ) {
    console.log(' this is login ');

  }

  ////////////////////////////////
  // headers for HTTPCLIENT calls
  private httpClientHeaders() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
  }
}