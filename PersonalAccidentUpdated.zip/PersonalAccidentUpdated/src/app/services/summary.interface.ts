export interface Payment {
    message: "Approved"
    reference: 1542865355587771
    status: "success"
    trans: "1337739714"
    transaction: "1337739714"
    trxref: "1542865355587771"
    amount: 2000
    transId: 152
   
}


export interface Pay {

    
        transId: 0;
        message: string;
        reference: string;
        status: string;
        transaction: string;
        trxref: string;
        amount: 0;
        customerInfo: {
          firstName: string;
          lastName: string;
          dateOfBirth: string;
          maritalStatus: string;
          phoneNumber: string;
          address: string;
          state: string;
          emailAddress: string;
          gender: string;
          localGovernment: string;
      }
    }

export interface Email {

    
 
    subject: string;
    mailBody: string;
    receipent: string;
    salutation: string;
  }
      



