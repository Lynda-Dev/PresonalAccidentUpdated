export interface Policy {
  policyNo: string
}

export interface Formkyc {
  medicalRequest: {
    height: string;
    weight: string;
    presentHealthState: string;
    generalHealthState: string;
    varyHealth: string;
    previousAccident: string;
    consultatation: string;
    healthComplaint: string;
    hospitalVisit: string;
    medication: string;
    prescription: string;
    exceededPrescription: string;
    medicalTest: string;
    nightUrinate: string;
    urineFrequency: string;
    urineDuration: string;
    breakdown: string;
    entDisease: string;
    cardio: string;
    highBP: string;
  };

  kycRequest: {
    firstName: string;
    lastName: string;
    email: string;
    mobilePhone: string;
    homePhone: string;
    address: string;
    stateOfOriginId: string;
    lgaId: string;
    homeTown: string;
    nationality: string;
    idType: string;
    idURL: string;
    idIssueLocation: string;
    idNumber: string;
    idIssueDate: string;
    dob: string;
    gender: string;
    maritalStatus: string;
    mothersMaidenName: string;
    occupation: string;
    employmentType: string;
    employer: string;
    employerAddress: string;
    employerPhone: string;
  };

  paRequest: {
    fit: boolean;
    productId: number;
    discount: boolean;
    frequentTraveller: string;
    machineryUser: string;
    accidentHistory: string;
    activePAPolicy: string;
  };
}
