import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.services';
import { FormControl, FormGroupDirective, NgForm, Validators, FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthResponse, Login } from '../services/login.Interface';
import { AdminService } from '../services/login-admin.services';
import { Admin } from '../services/login-admin.interface';


@Component({
  selector: 'app-login-admin',
  templateUrl: './login-admin.component.html',
  styleUrls: ['./login-admin.component.css']
})
export class LoginAdminComponent implements OnInit {
  public loginAdminErr = false;
  public loginIn = false;

  loginAdminFormGroup!: FormGroup;
  constructor(
    private fb: FormBuilder,
    private adminService: AdminService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.loginAdminFormGroup = this.fb.group(
      {
      username: ['', Validators.required],
        doorKey: ['', Validators.required]
      }
    )
  }
  adminUSer() {
    this.loginAdminErr = false;

    const payload: Admin = {
      username: this.loginAdminFormGroup.get('username')?.value, 
      doorKey: this.loginAdminFormGroup.get('doorKey')?.value
    }

    this.adminService.admin(payload)
      .subscribe(
        res => {
          console.log('response: ', res);

          let response: any; 
          
          response = res;

          localStorage.setItem('username', response['data']['username']);
          localStorage.setItem('doorKey', response['data']['doorKey']);
          localStorage.setItem('token', response['data']['bearerToken']);

          this.router.navigate(['/profile'], { relativeTo: this.route });
        },
        () => {
          this.loginAdminErr = true;
        }
      )

  }

  }
