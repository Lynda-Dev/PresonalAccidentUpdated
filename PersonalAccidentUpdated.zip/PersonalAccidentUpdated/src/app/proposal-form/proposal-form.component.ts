import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proposal-form',
  templateUrl: './proposal-form.component.html',
  styleUrls: ['./proposal-form.component.css']
})
export class ProposalFormComponent implements OnInit {

  plans = [
    'Platinum',
    'Gold',
    'Silver',
    'Bronze'
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
