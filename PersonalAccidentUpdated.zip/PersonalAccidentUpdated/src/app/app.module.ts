import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { KYCComponent } from './kyc/kyc.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HomeComponent } from './home/home.component';

import { MaterialModule } from '../app/ui/material/material.module';

import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { KycFormComponent } from './kyc-form/kyc-form.component';
import { ProposalFormComponent } from './proposal-form/proposal-form.component';
import { MedicalFormComponent } from './medical-form/medical-form.component';
import { PaymentFormComponent } from './payment-form/payment-form.component';
import { LoginComponent } from './login/login.component';
import { LandingComponent } from './landing/landing.component';
import { ProfileLoginComponent } from './profile-login/profile-login.component';
import { RegisterComponent } from './register/register.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginAdminComponent } from './login-admin/login-admin.component';
import { ResetPassComponent } from './reset-pass/reset-pass.component';
import { NewCustomerComponent } from './new-customer/new-customer.component'
import { Angular4PaystackModule } from 'angular4-paystack';
import { SummaryComponent } from './summary/summary.component';
import { MarkAsteriskDirective } from './directive/mark-asterisk.directive';
import { CustomerCareComponent } from './customer-care/customer-care.component';


@NgModule({
  
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    CommonModule,
    FormsModule,
    Angular4PaystackModule.forRoot('pk_test_80910945ffed22f22bd35b6c6e6b047579f93267'),
    ReactiveFormsModule,
    MaterialModule,
    BrowserAnimationsModule,
    HttpClientModule
  ],
  declarations: [
    AppComponent,
    KYCComponent,
    HomeComponent,  
    HeaderComponent, 
    KycFormComponent, 
    ProposalFormComponent, 
    MedicalFormComponent, 
    PaymentFormComponent, 
    LoginComponent, 
    LandingComponent, 
    ProfileLoginComponent, 
    RegisterComponent, LoginAdminComponent, ResetPassComponent, NewCustomerComponent, SummaryComponent, MarkAsteriskDirective, CustomerCareComponent

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
