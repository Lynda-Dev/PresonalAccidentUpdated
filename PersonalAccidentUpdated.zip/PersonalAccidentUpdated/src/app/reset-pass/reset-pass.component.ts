import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.services';
import { FormControl, FormGroupDirective, NgForm, Validators, FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthResponse, Login } from '../services/login.Interface';
import { ResetService } from '../services/reset.services';
import { Reset } from '../services/reset.interface';

@Component({
  selector: 'app-reset-pass',
  templateUrl: './reset-pass.component.html',
  styleUrls: ['./reset-pass.component.css']
})
export class ResetPassComponent implements OnInit {
  public resetErr = false;
  public resetIn = false;
  public confirmpass = false;

  resetFormGroup!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private resetService: ResetService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.resetFormGroup = this.fb.group(
      {
        email: ['', Validators.required],
        kokoro: ['', Validators.required],
        confirmkokoro: ['', Validators.required]
      }
    )
  }

  resetUser() {
    this.resetErr = false;

    const payload: Reset = {
      confirmkokoro: this.resetFormGroup.get('kokoro2')?.value,
      kokoro: this.resetFormGroup.get('kokoro')?.value,
      email: this.resetFormGroup.get('email')?.value
    }
    
    this.resetService.reset(payload)
      .subscribe(
        res => {
          console.log('response: ', res);

          this.resetFormGroup.reset();

          let response: any;

          response = res;

          localStorage.setItem('email', response['data']['email']);
          localStorage.setItem('kokoro', response['data']['kokoro']);
          localStorage.setItem('token', response['data']['bearerToken']);

          this.router.navigate(['/profile'], { relativeTo: this.route });
        },
        () => {
          this.resetErr = true;
        }
      )
  }

  confirm() {

    this.confirmpass = false;

    if (this.resetFormGroup.get('kokoro')?.value == this.resetFormGroup.get('kokoro2')?.value) {
      console.log('password match');



    }




  }
}



