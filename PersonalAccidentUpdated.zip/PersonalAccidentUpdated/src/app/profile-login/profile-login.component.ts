import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-login',
  templateUrl: './profile-login.component.html',
  styleUrls: ['./profile-login.component.css']
})
export class ProfileLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
