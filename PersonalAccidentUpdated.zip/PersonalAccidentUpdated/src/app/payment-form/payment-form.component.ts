import { Summary } from '@angular/compiler';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { RegisterService } from '../services/register.services';
import { ThemePalette } from '@angular/material/core';
import { ProgressSpinnerMode } from '@angular/material/progress-spinner';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { Injectable } from '@angular/core';





@Component({
  selector: 'app-payment-form',
  templateUrl: './payment-form.component.html',
  styleUrls: ['./payment-form.component.css']
})
export class PaymentFormComponent implements OnInit {


  public name = 'Obi';
  public email = 'Lynda@gmail';
  public type = 'Gold';
  public amount = 2000;
  public tranId: any = 6;
  public refn = '0';
  public dob = '1981-01-01';
  public lgaId = '';
  public employerAddress = 'Office Tola';
  public address = 'Resident Bola';
  public stateOfOriginId = 'Lagos';
  public mobilePhone = '0819068741';
  public gender = 'M';
  public maritalStatus = 'M';
  public city = 'Lagos';
  public subject = "PAYMENT CONFIRMED";
  public mailBody = "<p>Yours truly</p>";
  public loadingRes = false;

  public paidnowloading = false;


  constructor(
    private route: ActivatedRoute,
    private registerService: RegisterService,
    private router: Router,


  ) {
    // this.dob = moment(
    //   new Date(this.route.snapshot.params.dob),
    //   "MMM Do YY",
    // ).format();


    this.dob = moment(this.route.snapshot.params.dob).format("YYYY-MM-DD")

    this.lgaId = this.route.snapshot.params.lgaId;
    this.employerAddress = this.route.snapshot.params.employerAddress;
    this.address = this.route.snapshot.params.address;
    this.stateOfOriginId = this.route.snapshot.params.stateOfOriginId;
    this.mobilePhone = this.route.snapshot.params.mobilePhone;
    this.gender = this.route.snapshot.params.gender;
    this.maritalStatus = this.route.snapshot.params.maritalStatus;
    this.city = this.route.snapshot.params.address;

    this.name = this.route.snapshot.params.name;
    this.email = this.route.snapshot.params.email;
    this.type = this.route.snapshot.params.productType;
    this.amount = this.route.snapshot.params.amount;
    this.tranId = this.route.snapshot.params.tranId ? parseInt(this.route.snapshot.params.tranId) : '';
    console.log('this.name');
    console.log(this.name);
    this.refn = Math.round(Math.random() * 2464244598537524).toString();


  }



  ngOnInit(): void {
  }


  processPayment() {

    document.getElementById('paybtn')?.click()


  }

  public paymentCancel() {


  }


  public paymentDone(e: any) {
    this.paidnowloading =  true;
    console.log('Payment is odne')
    console.log(e) 

    this.creatPolicy(e)

  }



  private creatPolicy(e: any) {

   

    var response: any;
    // var payload = {
    //   "type": this.type,
    //   "name": this.name,
    //   "transId": this.tranId,
    //   "message": e.message.toString(),
    //   "reference": e.reference.toString(),
    //   "status": e.status.toString(),
    //   "transaction": e.transaction.toString(),
    //   "trxref": e.trxref.toString(),
    //   "amount": parseFloat(this.amount.toString()).toFixed(2),
    //   "customerInfo":{
    //     "dateOfBirth": this.dob,
    //     "maritalStatus": this.maritalStatus,
    //     "phoneNumber": this.mobilePhone,
    //     "address": this.address,
    //     "state": this.stateOfOriginId,
    //     "emailAddress": this.email,
    //     "gender": this.gender,
    //     "localGovernment": this.lgaId,
    //   } 
    // }

    var payload = {
      "amount": parseFloat(this.amount.toString()).toFixed(2),
      "message": e.message.toString(),
      "reference": e.reference.toString(),
      "status": e.status.toString(),
      "transId": this.tranId,
      "transaction": e.transaction.toString(),
      "trxref": e.trxref.toString(),
      customerInfo: {
        "firstName": this.name.trim().split(' ')[0],
        "lastName": this.name.trim().split(' ')[1],
        "dateOfBirth": this.dob,
        "maritalStatus": this.maritalStatus,
        "phoneNumber": this.mobilePhone,
        "address": this.address,
        "emailAddress": this.email,
        "gender": this.gender,
        "localGovernment": this.lgaId,
        "state": this.stateOfOriginId,
      }
    }

    console.log('This is the')
    console.log(payload)
    this.registerService.createpolicy(payload).subscribe(res => {
      console.log('res')
      console.log(res)
      response = res;

      if (response['status'] === true) {
        console.log(res);
  
        // TODO: implement send email
        // this.sendEmail();
        this.paidnowloading =  false;
        this.router.navigate(['/summary', {
          policyNo: response['data']['policyNo'], message: response['message'],
          name: this.route.snapshot.params.name, amount: this.route.snapshot.params.amount,
          type: this.route.snapshot.params.productType, address: this.route.snapshot.params.address
        }]);

      } else {
        // TODO: Notify user that payment was not successful!
        this.paidnowloading =  false;

      }
    })
  }


  private sendEmail() {
    var response: any;
    var payload = {

      "subject": this.subject,
      "mailBody": this.mailBody,
      "receipent": this.route.snapshot.params.email,
      "salutation": this.route.snapshot.params.name,
    }

    this.registerService.sendEmail(payload)
      .subscribe(res => {
        console.log('res')
        console.log(res);

        response = res;

        if (response['code'] === '00') {

        }
      })

  }

}


// transid
// message: "Approved"
// reference: "1542865355587771"
// status: "success"
// trans: "1337739714"
// transaction: "1337739714"
// trxref: "1542865355587771"