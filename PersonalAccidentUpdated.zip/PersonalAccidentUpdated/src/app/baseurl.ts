// export const baseUrl = 'http://172.18.13.19/PersonalAccidentAPI';
// export const baseUrl = 'http://172.18.13.26/personalAccident';
 export const baseUrl = 'http://172.31.60.149/personalAccident';

