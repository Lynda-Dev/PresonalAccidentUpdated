import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { FormService } from '../services/form.services';
import { FormControl, FormGroupDirective, NgForm, Validators, FormArray, FormBuilder, FormGroup, Form } from '@angular/forms';
import { Formkyc } from '../services/form.interface';
import { RegisterService } from '../services/register.services';
import { Register } from '../services/register.interface';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  public submitErr = false;
  public submitIn = false;

  regFormGroup!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private registerService: RegisterService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.regFormGroup = this.fb.group(
      {

        firstName: ['', Validators.required],
        lastName: ['', Validators.required],
        email: ['', Validators.required],
        mobilePhone: ['', Validators.required],
        kokoro: ['', Validators.required]
      }
    )
  }

  regFormUser() {
    this.submitErr = false;

    const payload: Register = {

      firstName: this.regFormGroup.get('firstName')?.value,
      lastName: this.regFormGroup.get('lastName')?.value,
      email: this.regFormGroup.get('email')?.value,
      mobilePhone: this.regFormGroup.get('mobilePhone')?.value,
      kokoro: this.regFormGroup.get('kokoro')?.value
    }

    console.log('payload: ', payload);

    

    this.registerService.SaveData(payload)
    .subscribe(
      res => {
        console.log(res)

        this.regFormGroup.reset();

        const resData: any = res;

        if (resData['code'] === '00') {
          
        }

        // code: "00"
        // error: "Account created successfully!"
        // status: "201"
      },
      error => {
        console.log(error)

        this.submitErr = true;
      }
    )

  }

  
}

// res => {
//   console.log('response: ', res);

//   let response: any;

//   response = res;

//   this.router.navigate(['/profile'], { relativeTo: this.route });
// },
// () => {
//   this.submitErr = true;
// }
