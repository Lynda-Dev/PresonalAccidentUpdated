import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medical-form',
  templateUrl: './medical-form.component.html',
  styleUrls: ['./medical-form.component.css']
})
export class MedicalFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
