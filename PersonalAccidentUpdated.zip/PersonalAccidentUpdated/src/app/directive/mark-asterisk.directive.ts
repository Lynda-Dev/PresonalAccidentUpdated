import { Directive } from '@angular/core';

@Directive({
  selector: '[appMarkAsterisk]'
})
export class MarkAsteriskDirective {

  constructor() { }

}
